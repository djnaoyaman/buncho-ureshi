J. S. Bach — Wachet auf, ruft uns die Stimme, BWV 645
おもちの文鳥ぐらし / #31 まるい冠の花庭 独立候補素材
2026-11-19

STATUS: NOT PUBLISHED. Not a replacement of existing garden audio. No Runway credits used.

1. Attribution and terms
Composition: Johann Sebastian Bach (1685–1750), BWV 645; historical composition is public domain.
Digital score and MIDI: Bart Golsteijn, Mutopia Project, Mutopia-2006/06/29-601.
Source declared by edition: Bach-Gesellschaft, Leipzig.
https://www.mutopiaproject.org/cgibin/piece-info.cgi?id=601
Digital edition license: Creative Commons Attribution-ShareAlike 2.5.
https://creativecommons.org/licenses/by-sa/2.5/
The edition, derived note events and these independent audio adaptations are supplied as CC BY-SA 2.5 material. Retain title, Bach/Bart Golsteijn/Mutopia credit, source link, license link and this modification notice. No endorsement is implied. Do not add DRM or incompatible restrictions to this material. This is an independent audio/source package, NOT a proposed relicensing of the game code. Integration licensing must be checked separately before publication.

Changes: tempo set to quarter=72; selected passage; synthetic pipe registration and modest pedal; short note-release gaps; stereo positioning; newly synthesized room response; cyclic tail handling for loop candidate. The MIDI carries simplified ornament playback: not every printed trill/mordent is realized. This is an arranged digital performance candidate, not an archival/original-instrument recording and not a fully critically edited performance.
No commercial recording, existing recorded performance, soundfont, sample library or recorded room impulse used. Every audio sample is calculated from oscillators and synthetic room impulse in render.py. No generative-AI music service used.

2. Sources and limits of verification
Downloaded official Mutopia LilyPond, MIDI, PDF and item HTML; preserved unmodified in sources/. The LilyPond header explicitly credits Bart Golsteijn, BGA and CC BY-SA 2.5.
IMSLP item page identifies BGA Band 25 pp.63–65, Wilhelm Rust, Leipzig 1878, public domain; also first edition ca.1748. Historical scan retrieval encountered an IMSLP bot check. The returned HTML is preserved as imslp-bot-check.html, NOT misrepresented as a PDF. No challenge was solved. Therefore independent note-by-note historical-source collation is NOT complete and no claim of modern-license-free self-transcription is made.
https://imslp.org/wiki/Wachet_auf,_ruft_uns_die_Stimme,_BWV_645_(Bach,_Johann_Sebastian)
Official Mutopia PDF page 2 was visually checked for m.13–22: three separate voices; chorale entrance E-flat–G–B-flat and B-flat repetitions; first ending and repeat at end of m.22. MIDI events preserve these tested pitches/onsets; events.json provides all extracted notes. Source grace-note scheduling and ornaments require further musical review. A MIDI is note data only; no audio recording was reused.

3. Candidate selection
A: BWV645-garden31-repeat-candidate — 70.000 s, 72 BPM, m.2–22 first-ending repeat (MIDI quarter-beat positions 4.5–88.5). Uses the written repeat as a musically motivated return, retaining the recognizable independent upper melody and chorale entry. Synthetic release/room tails are wrapped around the period, not crossfaded across unrelated music. No fade-out. Preferred loop candidate, pending listening.
B: BWV645-garden31-opening-preview — opening pickup through first ending plus natural room decay. Shows the familiar opening and first chorale section; NOT a seamless loop because it includes the non-repeating introductory bar.
C examined but not rendered: m.13–16 alone gives chorale's initial line quickly, but its ending already prepares the next line and would splice prematurely. Rejected for fragmentary musical form.

4. Reproduction and QA
Python 3 + numpy + scipy and ffmpeg required. Run read_midi.py then render.py from any working directory. No proprietary plugins/assets required. Render settings and hashes: render-report.json. Note data: events.json. Original score source: sources/bwv645.ly, .mid, .pdf. Both WAV and MP3 retain the same performance; MP3 encoding delay must be handled by the eventual player. Prefer WAV for seamless playback tests.
Technical checks are not artistic acceptance: instrumental realism, comfort with birds, mobile small-speaker balance and at least three actual loop plays remain to be judged. Existing #15 and #31 audio have not been changed or deleted. Do not publish this candidate as a finished score-faithful Bach performance until the ornament and listening checks pass.

日本語の短い帰属表示案:
J.S.バッハ《目覚めよ、と呼ぶ声あり》BWV 645（一部・独自合成演奏）
デジタル楽譜：Bart Golsteijn / Mutopia Project（CC BY-SA 2.5）
変更：抜粋・テンポ・音色・残響・装飾音の簡略化。音源もCC BY-SA 2.5。
https://www.mutopiaproject.org/cgibin/piece-info.cgi?id=601
https://creativecommons.org/licenses/by-sa/2.5/
