import struct,json,pathlib
# Minimal Standard MIDI parser: deterministic note-data extraction only, no audio samples.
def read(path):
 b=pathlib.Path(path).read_bytes();_,n,ppq=struct.unpack('>HHH',b[8:14]);pos=14;tracks=[]
 for ti in range(n):
  assert b[pos:pos+4]==b'MTrk';size=int.from_bytes(b[pos+4:pos+8],'big');d=b[pos+8:pos+8+size];pos+=8+size;i=0;t=0;running=0;active={};notes=[];meta=[]
  def vlq():
   nonlocal i
   x=0
   while True:
    v=d[i];i+=1;x=(x<<7)|(v&127)
    if v<128:return x
  while i<len(d):
   t+=vlq();s=d[i]
   if s>=128:i+=1
   else:s=running
   if s==255:
    typ=d[i];i+=1;l=vlq();v=d[i:i+l];i+=l;meta.append((t/ppq,typ,v.hex()));continue
   if s in (240,247):i+=vlq();continue
   running=s;k=s>>4;ch=s&15;nn=1 if k in (12,13) else 2;v=d[i:i+nn];i+=nn
   if k==9 and v[1]:active[(ch,v[0])]=(t,v[1])
   if k==8 or (k==9 and v[1]==0):
    st,vel=active.pop((ch,v[0]));notes.append({'start':st/ppq,'end':t/ppq,'pitch':v[0],'velocity':vel,'channel':ch})
  tracks.append({'index':ti,'notes':sorted(notes,key=lambda x:x['start']),'meta':meta})
 return {'ppq':ppq,'tracks':tracks}
if __name__=='__main__':
 p=pathlib.Path(__file__).parent;r=read(p/'sources/bwv645.mid');(p/'events.json').write_text(json.dumps(r,indent=2))
 for t in r['tracks']:
  print(t['index'],len(t['notes']),t['meta'][:5],t['notes'][:6])
