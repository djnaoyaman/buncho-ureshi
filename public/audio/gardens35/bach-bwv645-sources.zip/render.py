"""Sample-free additive pipe-organ rendering. Score data: Bart Golsteijn / Mutopia 601, CC BY-SA 2.5.
This independent audio adaptation is offered under CC BY-SA 2.5. No recorded samples/IRs.
Run python3 read_midi.py then python3 render.py. Requires numpy, scipy, ffmpeg.
"""
import json,pathlib,numpy as np,hashlib,subprocess
from scipy.io import wavfile
from scipy.signal import fftconvolve
P=pathlib.Path(__file__).parent;SR=44100;BPM=72;SPB=60/BPM
tracks=json.loads((P/'events.json').read_text())['tracks'][1:]
# Attack/release and registration differ per manual/pedal, avoiding blunt GM organ.
REG=[([1,.30,.15,.075,.035,.015],.18,0.035,.085,-.22),([1,.19,.10,.045,.018],.25,.055,.12,.20),([1,.13,.035],.105,.045,.11,0)]
def tone(pitch,dur,v):
 harms,amp,attack,release,pan=REG[v];f=440*2**((pitch-69)/12);nn=int((dur+release)*SR);t=np.arange(nn)/SR
 # Gentle wind-pressure modulation, stable deterministic oscillators. Not a sampled organ.
 wind=1+.0012*np.sin(2*np.pi*.47*t+pitch*.71);x=np.zeros(nn)
 for h,a in enumerate(harms,1):
  if f*h<SR*.43:x+=a*np.sin(2*np.pi*f*h*t+.012*h)*wind
 if v==2:x+=.17*np.sin(2*np.pi*(f/2)*t) # quiet 16-foot support
 env=np.minimum(t/attack,1);env=np.sin(env*np.pi/2)**2
 tail=np.clip((t-dur)/release,0,1);env*=np.cos(tail*np.pi/2)**2
 return x*env*amp,pan
# Synthetic room impulse, no external IR/license.
rng=np.random.default_rng(645);irlen=int(.65*SR);ir=np.zeros((irlen,2));ir[0]=1
for ch in range(2):
 for sec,gain in [(.023,.14),(.037,.10),(.053,.073),(.079,.05)]:ir[int((sec+ch*.0017)*SR),ch]+=gain
 noise=rng.normal(size=irlen);noise=np.convolve(noise,np.ones(9)/9,'same');tt=np.arange(irlen)/SR
 ir[:,ch]+=noise*np.exp(-tt*11)*.006*(tt>.06)
def build(name,start,end,cyclic):
 dur=(end-start)*SPB;N=round(dur*SR);extra=int(SR);stems=[]
 for v,tr in enumerate(tracks):
  sig=np.zeros((N+extra,2));count=0
  for n in tr['notes']:
   if not(start<=n['start']<end):continue
   on=round((n['start']-start)*SPB*SR);d=(min(n['end'],end)-n['start'])*SPB
   d=max(.025,d-min(.018,d*.035));x,pan=tone(n['pitch'],d,v);l=len(x)
   sig[on:on+l,0]+=x*np.sqrt((1-pan)/2);sig[on:on+l,1]+=x*np.sqrt((1+pan)/2);count+=1
  wet=np.stack([fftconvolve(sig[:,c],ir[:,c]) for c in range(2)],axis=1)
  if cyclic:
   out=wet[:N].copy()
   for off in range(N,len(wet),N):out[:len(wet[off:off+N])]+=wet[off:off+N]
  else:out=wet[:N+int(.8*SR)]
  stems.append(out)
 y=sum(stems);gain=.28/max(np.max(abs(y)),1e-9);y*=gain
 f=P/(name+'.wav');wavfile.write(f,SR,(np.clip(y,-1,1)*32767).astype(np.int16))
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(f),'-codec:a','libmp3lame','-b:a','192k',str(P/(name+'.mp3'))],check=True)
 stats={'file':f.name,'seconds':len(y)/SR,'bpm':BPM,'score_quarter_beats':[start,end],'cyclic_room_tail':cyclic,'peak_dbfs':float(20*np.log10(abs(y).max())),'rms_dbfs':float(20*np.log10(np.sqrt(np.mean(y*y)))),'boundary_sample_step':float(abs(y[0]-y[-1]).max()),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
 return stats
stats=[build('BWV645-garden31-repeat-candidate',4.5,88.5,True),build('BWV645-garden31-opening-preview',0,88.5,False)]
(P/'render-report.json').write_text(json.dumps(stats,indent=2));print(json.dumps(stats,indent=2))
